# Tamil Theme Keyboard (Android Studio project)

A starter Android IME keyboard project with:
- Native Tamil key output (not Tanglish transliteration)
- A Tamil99-inspired arrangement based on the provided Sellinam screenshot
- Dark/light colours selected from the Android system night mode
- No network permission and no account or analytics code

## Build
1. Open this folder in Android Studio (Giraffe or newer recommended).
2. Let Gradle sync. Use JDK 17.
3. Build > Build APK(s).
4. Install the generated debug APK on your Oppo phone.
5. Open the app, tap **Enable keyboard in Settings**, enable **Tamil Theme Keyboard**, then return and tap **Choose keyboard**.

## Important prototype note
This is a starter implementation, not a verified replacement for Sellinam. The key map is Tamil99-inspired and must be checked against the exact official Tamil99 standard and your preferred Sellinam mapping before daily use. This first version does not yet include full Tamil vowel-consonant composition, number/symbol pages, long-press alternatives, predictive typing, or clipboard features. It uses system light/dark mode as the theme signal; ColorOS may expose its own theme colours differently from Android's night mode.
