package com.example.tamilthemkeyboard

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.ViewGroup
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.content.res.Configuration
import android.view.inputmethod.InputConnection
import android.view.KeyEvent
import android.graphics.drawable.GradientDrawable

class TamilKeyboardService : InputMethodService() {
    private var dark = true
    private var keyboardRoot: LinearLayout? = null

    // Tamil99-inspired native Tamil layout. Key output is Tamil Unicode, not transliteration.
    private val rows = listOf(
        listOf("ஆ", "ஃ", "ஊ", "ஏ", "ஐ", "ஓ", "ற", "ன", "ல", "ண", "ச", "ஞ"),
        listOf("அ", "இ", "உ", "எ", "ஐ", "ஜ", "க", "ப", "ம", "த", "ந", "ய"),
        listOf("ஒ", "ஔ", "ி", "ீ", "ு", "ூ", "ெ", "ே", "ை", "ொ", "ோ", "ௌ")
    )

    override fun onCreateInputView(): View {
        dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
        return buildKeyboard()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        dark = (newConfig.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        if (isInputViewShown) setInputView(buildKeyboard())
    }

    private fun buildKeyboard(): View {
        val bg = if (dark) Color.rgb(31, 39, 42) else Color.rgb(235, 240, 241)
        val key = if (dark) Color.rgb(39, 49, 53) else Color.rgb(250, 252, 252)
        val fg = if (dark) Color.rgb(225, 231, 233) else Color.rgb(30, 40, 42)
        val accent = if (dark) Color.rgb(128, 203, 196) else Color.rgb(0, 121, 107)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(5), dp(4), dp(7))
            setBackgroundColor(bg)
        }
        keyboardRoot = root

        // Suggestion strip / quick words, similar to the reference screenshot.
        val suggestions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(3))
        }
        listOf("அது", "ஆனால்", "நான்").forEach { word ->
            val t = TextView(this).apply {
                text = word
                textSize = 17f
                gravity = Gravity.CENTER
                setTextColor(fg)
                setOnClickListener { commit(word) }
            }
            suggestions.addView(t, LinearLayout.LayoutParams(0, dp(36), 1f))
        }
        root.addView(suggestions)

        rows.forEach { row ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            row.forEach { symbol ->
                line.addView(makeKey(symbol, key, fg) { commit(symbol) },
                    LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                        setMargins(dp(1), dp(2), dp(1), dp(2))
                    })
            }
            root.addView(line)
        }

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        bottom.addView(makeKey("?123", key, fg) { commit("?123") }, weight(1.15f))
        bottom.addView(makeKey("⇧", key, fg) { }, weight(0.8f))
        bottom.addView(makeKey("⌫", key, fg) { deleteOne() }, weight(0.9f))
        bottom.addView(makeKey("தமிழ்", key, fg) { commit(" ") }, weight(2.2f))
        bottom.addView(makeKey(",", key, fg) { commit(",") }, weight(0.7f))
        bottom.addView(makeKey(".", key, fg) { commit(".") }, weight(0.7f))
        bottom.addView(makeKey("↵", accent, if (dark) Color.rgb(20, 45, 43) else Color.WHITE) {
            currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }, weight(1.1f))
        root.addView(bottom)
        return root
    }

    private fun makeKey(label: String, fill: Int, text: Int, action: () -> Unit): TextView {
        return TextView(this).apply {
            this.text = label
            textSize = if (label.length > 2) 15f else 21f
            setTextColor(text)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT
            background = GradientDrawable().apply {
                setColor(fill)
                cornerRadius = dp(5).toFloat()
            }
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
    }

    private fun weight(w: Float) = LinearLayout.LayoutParams(0, dp(46), w).apply {
        setMargins(dp(1), dp(3), dp(1), dp(1))
    }

    private fun commit(text: String) {
        currentInputConnection?.commitText(text, 1)
    }

    private fun deleteOne() {
        val ic: InputConnection = currentInputConnection ?: return
        ic.deleteSurroundingText(1, 0)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
